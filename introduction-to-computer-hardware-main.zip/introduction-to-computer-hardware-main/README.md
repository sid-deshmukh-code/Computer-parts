##introduction-to-computer-hardware

[Introduction to Computer Ports](https://github.com/harshalparmar/introduction-to-computer-hardware/blob/main/Introduction%20to%20Computer%20Ports.txt)

[Introduction to Motherboard](https://github.com/harshalparmar/introduction-to-computer-hardware/blob/main/Introduction%20to%20Motherboard.txt)

[Introduction to Types of Computer Cables](https://github.com/harshalparmar/introduction-to-computer-hardware/blob/main/Introduction%20to%20Types%20of%20Computer%20Cables.txt)

[Introduction to Types of Computer Hardware](https://github.com/harshalparmar/introduction-to-computer-hardware/blob/main/Introduction%20to%20Types%20of%20Computer%20Hardware.txt)
